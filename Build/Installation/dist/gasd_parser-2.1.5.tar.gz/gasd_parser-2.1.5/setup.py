from setuptools import find_packages, setup


setup(
    name="gasd_parser",
    version="2.1.5",
    packages=find_packages(),
    install_requires=[
        "antlr4-python3-runtime==4.13.1",
    ],
    entry_points={
        "console_scripts": [
            "gasd_parser=gasd_parser.cli:main",
        ],
    },
)
