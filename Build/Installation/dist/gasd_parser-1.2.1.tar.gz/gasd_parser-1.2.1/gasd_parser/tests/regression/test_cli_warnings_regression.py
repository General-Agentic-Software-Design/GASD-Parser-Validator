import pytest
import subprocess
import os
import tempfile

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", ".."))

def run_cli(file_path, *args):
    result = subprocess.run(
        ["python3", "-m", "gasd_parser", file_path, *args],
        capture_output=True, text=True,
        env={**os.environ, "PYTHONPATH": PROJECT_ROOT},
        cwd=PROJECT_ROOT
    )
    return result

def test_cli_ast_warnings():
    """Verify --ast shows Phase 3 warnings and summary includes them."""
    gasd_content = """CONTEXT: "Test"\nTARGET: "Any"\nNAMESPACE: "n"\nTYPE T:\n  f: UnknownType\n"""
    with tempfile.NamedTemporaryFile(suffix=".gasd", delete=False, mode="w") as tmp:
        tmp.write(gasd_content)
        file_path = tmp.name

    try:
        result = run_cli(file_path, "--ast")
        assert result.returncode == 0
        assert "OK Passed (with warnings):" in result.stderr
        assert "warning[SEMANTIC V008]: Unknown type reference: 'UnknownType'" in result.stderr
        assert "Warnings:        1" in result.stderr
    finally:
        if os.path.exists(file_path):
            os.unlink(file_path)

def test_cli_ast_sem_warnings():
    """Verify --ast-sem shows Phase 4 warnings and summary includes them."""
    gasd_content = """CONTEXT: "Test"\nTARGET: "Any"\nNAMESPACE: "n"\nCOMPONENT C:\n  INTERFACE:\n    m() -> String\nFLOW m() -> String:\n  1. ENSURE "c"\n  2. RETURN "d"\n"""
    with tempfile.NamedTemporaryFile(suffix=".gasd", delete=False, mode="w") as tmp:
        tmp.write(gasd_content)
        file_path = tmp.name

    try:
        result = run_cli(file_path, "--ast-sem")
        assert result.returncode == 0
        assert "OK Passed (with warnings):" in result.stderr
        assert "warning[SEMANTIC MissingOtherwise]: ENSURE block must have an OTHERWISE recovery path." in result.stderr
        assert "Warnings:        1" in result.stderr
    finally:
        if os.path.exists(file_path):
            os.unlink(file_path)
