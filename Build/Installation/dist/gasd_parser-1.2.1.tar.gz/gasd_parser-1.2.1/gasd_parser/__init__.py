"""GASD Parser & Validator Package"""
__version__ = "1.2.1"
