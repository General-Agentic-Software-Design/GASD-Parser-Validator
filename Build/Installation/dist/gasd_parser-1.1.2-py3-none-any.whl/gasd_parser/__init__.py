"""GASD Parser & Validator Package"""
__version__ = "1.1.2"
